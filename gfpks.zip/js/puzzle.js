// ------------------- НАСТРОЙКИ -------------------
let PUZZLE_DIFFICULTY = 10;   // 10x10 = 100 фрагментов по умолчанию
const PUZZLE_HOVER_TINT = '#ff88bb';   // розовая подсветка при наведении

// DOM элементы
let _stage;
let _canvas;
let _img;
let _pieces = [];
let _puzzleWidth, _puzzleHeight, _pieceWidth, _pieceHeight;
let _currentPiece = null;
let _currentDropPiece = null;
let _mouse = { x: 0, y: 0 };

// Игровая экономика
let playerCoins = 100;
let totalPuzzlesCompleted = 0;     // общее количество правильно поставленных фрагментов (счётчик рейтинга)
let currentPlayerName = "Гость";
let ranking = [];

// Вспомогательные флаги
let hintActiveFor = null;          // индекс фрагмента, для которого активна подсказка
let hintTimeout = null;
let coinsOnField = [];             // массив { x, y, radius }

// ------------------- ЗАГРУЗКА РЕЙТИНГА И СОХРАНЕНИЕ -------------------
function loadRanking() {
    const stored = localStorage.getItem('puzzleRanking');
    if (stored) {
        ranking = JSON.parse(stored);
    } else {
        ranking = [];
    }
    if (!ranking.some(p => p.name === currentPlayerName)) {
        ranking.push({ name: currentPlayerName, score: 0, coins: 100 });
        saveRanking();
    }
    updateRankingUI();
}

function saveRanking() {
    localStorage.setItem('puzzleRanking', JSON.stringify(ranking));
}

function updateRankingUI() {
    const ratingDiv = document.getElementById('ratingList');
    if (!ratingDiv) return;
    const sorted = [...ranking].sort((a,b) => b.score - a.score);
    ratingDiv.innerHTML = '';
    for (let p of sorted) {
        const div = document.createElement('div');
        div.className = 'rating-item';
        div.innerHTML = `<span>${escapeHtml(p.name)}</span><span>🧩 ${p.score}  💰${p.coins}</span>`;
        ratingDiv.appendChild(div);
    }
}

function updateCurrentPlayerInRanking() {
    const idx = ranking.findIndex(p => p.name === currentPlayerName);
    if (idx !== -1) {
        ranking[idx].score = totalPuzzlesCompleted;
        ranking[idx].coins = playerCoins;
    } else {
        ranking.push({ name: currentPlayerName, score: totalPuzzlesCompleted, coins: playerCoins });
    }
    saveRanking();
    updateRankingUI();
}

function updateUI() {
    document.getElementById('coinBalance').innerText = playerCoins;
    document.getElementById('puzzlesCompleted').innerText = totalPuzzlesCompleted;
    updateCurrentPlayerInRanking();
}

function addCoins(amount) {
    playerCoins += amount;
    updateUI();
}

function spendCoins(amount) {
    if (playerCoins >= amount) {
        playerCoins -= amount;
        updateUI();
        return true;
    }
    return false;
}

function addScore(piecesGained = 1) {
    totalPuzzlesCompleted += piecesGained;
    updateUI();
}

// ------------------- ОСНОВНЫЕ ФУНКЦИИ ПАЗЛА (drag-and-drop) -------------------
function init(difficulty) {
    document.ontouchmove = function(event){ event.preventDefault(); };
    PUZZLE_DIFFICULTY = difficulty;
    // Если картинка уже загружена пользователем – используем её, иначе стандартная
    if (!_img || !_img.src) {
        _img = new Image();
        _img.addEventListener('load', onImage, false);
        _img.src = "img/puzzle.jpg";   // запасная
    } else {
        // перезапуск с той же картинкой
        onImage();
    }
}

function onImage() {
    _pieceWidth = Math.floor(_img.width / PUZZLE_DIFFICULTY);
    _pieceHeight = Math.floor(_img.height / PUZZLE_DIFFICULTY);
    _puzzleWidth = _pieceWidth * PUZZLE_DIFFICULTY;
    _puzzleHeight = _pieceHeight * PUZZLE_DIFFICULTY;
    setCanvas();
    initPuzzle();
}

function setCanvas() {
    _canvas = document.getElementById('canvas');
    _stage = _canvas.getContext('2d');
    _canvas.width = _puzzleWidth;
    _canvas.height = _puzzleHeight;
    _canvas.style.border = "0px solid transparent";
}

function initPuzzle() {
    _pieces = [];
    _mouse = {x:0, y:0};
    _currentPiece = null;
    _currentDropPiece = null;
    _stage.drawImage(_img, 0, 0, _puzzleWidth, _puzzleHeight, 0, 0, _puzzleWidth, _puzzleHeight);
    createTitle("Нажмите, чтобы начать сборку");
    buildPieces();
}

function createTitle(msg) {
    _stage.fillStyle = "#000000";
    _stage.globalAlpha = 0.4;
    _stage.fillRect(100, _puzzleHeight - 40, _puzzleWidth - 200, 40);
    _stage.fillStyle = "#ff88bb";
    _stage.globalAlpha = 1;
    _stage.textAlign = "center";
    _stage.textBaseline = "middle";
    _stage.font = "18px 'Segoe UI', 'Quicksand'";
    _stage.fillText(msg, _puzzleWidth / 2, _puzzleHeight - 20);
}

function buildPieces() {
    let xPos = 0, yPos = 0;
    for (let i = 0; i < PUZZLE_DIFFICULTY * PUZZLE_DIFFICULTY; i++) {
        let piece = {};
        piece.sx = xPos;
        piece.sy = yPos;
        _pieces.push(piece);
        xPos += _pieceWidth;
        if (xPos >= _puzzleWidth) {
            xPos = 0;
            yPos += _pieceHeight;
        }
    }
    document.onmousedown = shufflePuzzle;
    document.getElementById('canvas').ontouchstart = shufflePuzzle;
}

function shufflePuzzle() {
    _pieces = shuffleArray(_pieces);
    _stage.clearRect(0, 0, _puzzleWidth, _puzzleHeight);
    let xPos = 0, yPos = 0;
    for (let i = 0; i < _pieces.length; i++) {
        let piece = _pieces[i];
        piece.xPos = xPos;
        piece.yPos = yPos;
        _stage.drawImage(_img, piece.sx, piece.sy, _pieceWidth, _pieceHeight, xPos, yPos, _pieceWidth, _pieceHeight);
        _stage.strokeRect(xPos, yPos, _pieceWidth, _pieceHeight);
        xPos += _pieceWidth;
        if (xPos >= _puzzleWidth) {
            xPos = 0;
            yPos += _pieceHeight;
        }
    }
    document.onmousedown = onPuzzleClick;
    document.getElementById('canvas').ontouchstart = onPuzzleClick;
}

function onPuzzleClick(e) {
    getMouseCoords(e);
    _currentPiece = checkPieceClicked();
    if (_currentPiece != null) {
        _stage.clearRect(_currentPiece.xPos, _currentPiece.yPos, _pieceWidth, _pieceHeight);
        _stage.save();
        _stage.globalAlpha = 0.9;
        _stage.drawImage(_img, _currentPiece.sx, _currentPiece.sy, _pieceWidth, _pieceHeight,
                         _mouse.x - (_pieceWidth/2), _mouse.y - (_pieceHeight/2), _pieceWidth, _pieceHeight);
        _stage.restore();
        document.onmousemove = updatePuzzle;
        document.getElementById('canvas').ontouchmove = updatePuzzle;
        document.onmouseup = pieceDropped;
        document.getElementById('canvas').ontouchend = pieceDropped;
    }
}

function getMouseCoords(e) {
    if (e.layerX || e.layerX == 0) {
        _mouse.x = e.layerX - _canvas.offsetLeft;
        _mouse.y = e.layerY - _canvas.offsetTop;
    } else if (e.offsetX || e.offsetX == 0) {
        _mouse.x = e.offsetX - _canvas.offsetLeft;
        _mouse.y = e.offsetY - _canvas.offsetTop;
    }
}

function checkPieceClicked() {
    for (let i = 0; i < _pieces.length; i++) {
        let piece = _pieces[i];
        if (_mouse.x >= piece.xPos && _mouse.x <= piece.xPos + _pieceWidth &&
            _mouse.y >= piece.yPos && _mouse.y <= piece.yPos + _pieceHeight) {
            return piece;
        }
    }
    return null;
}

function updatePuzzle(e) {
    _currentDropPiece = null;
    getMouseCoords(e);
    _stage.clearRect(0, 0, _puzzleWidth, _puzzleHeight);
    // Рисуем все фрагменты, кроме текущего
    for (let i = 0; i < _pieces.length; i++) {
        let piece = _pieces[i];
        if (piece == _currentPiece) continue;
        _stage.drawImage(_img, piece.sx, piece.sy, _pieceWidth, _pieceHeight, piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
        _stage.strokeRect(piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
        if (_currentDropPiece == null && isMouseOverPiece(piece)) {
            _currentDropPiece = piece;
            _stage.save();
            _stage.globalAlpha = 0.4;
            _stage.fillStyle = PUZZLE_HOVER_TINT;
            _stage.fillRect(_currentDropPiece.xPos, _currentDropPiece.yPos, _pieceWidth, _pieceHeight);
            _stage.restore();
        }
    }
    // Рисуем перетаскиваемый фрагмент
    _stage.save();
    _stage.globalAlpha = 0.6;
    _stage.drawImage(_img, _currentPiece.sx, _currentPiece.sy, _pieceWidth, _pieceHeight,
                     _mouse.x - (_pieceWidth/2), _mouse.y - (_pieceHeight/2), _pieceWidth, _pieceHeight);
    _stage.restore();
    _stage.strokeRect(_mouse.x - (_pieceWidth/2), _mouse.y - (_pieceHeight/2), _pieceWidth, _pieceHeight);
    
    // Дополнительно рисуем монетки поверх всего
    drawCoins();
    
    // Если активна подсказка, подсвечиваем целевое место
    if (hintActiveFor !== null && _pieces[hintActiveFor] && !isPiecePlacedCorrectly(_pieces[hintActiveFor])) {
        let target = _pieces[hintActiveFor];
        _stage.save();
        _stage.globalAlpha = 0.4;
        _stage.fillStyle = "#ff44aa";
        _stage.fillRect(target.sx, target.sy, _pieceWidth, _pieceHeight);
        _stage.restore();
        _stage.beginPath();
        _stage.strokeStyle = "#ff3399";
        _stage.lineWidth = 4;
        _stage.strokeRect(target.sx, target.sy, _pieceWidth, _pieceHeight);
    }
}

function isMouseOverPiece(piece) {
    return (_mouse.x >= piece.xPos && _mouse.x <= piece.xPos + _pieceWidth &&
            _mouse.y >= piece.yPos && _mouse.y <= piece.yPos + _pieceHeight);
}

function isPiecePlacedCorrectly(piece) {
    return (piece.xPos === piece.sx && piece.yPos === piece.sy);
}

function pieceDropped(e) {
    document.onmousemove = null;
    document.getElementById('canvas').ontouchmove = null;
    document.onmouseup = null;
    document.getElementById('canvas').ontouchend = null;
    if (_currentDropPiece != null) {
        // Меняем местами фрагменты
        let tmp = { xPos: _currentPiece.xPos, yPos: _currentPiece.yPos };
        _currentPiece.xPos = _currentDropPiece.xPos;
        _currentPiece.yPos = _currentDropPiece.yPos;
        _currentDropPiece.xPos = tmp.xPos;
        _currentDropPiece.yPos = tmp.yPos;
        
        // Если фрагмент встал на своё правильное место – начисляем награду
        if (_currentPiece.xPos === _currentPiece.sx && _currentPiece.yPos === _currentPiece.sy) {
            addCoins(5);
            addScore(1);
        }
        // Если целевой фрагмент (с которым поменялись) тоже оказался на своём месте – тоже награда
        if (_currentDropPiece.xPos === _currentDropPiece.sx && _currentDropPiece.yPos === _currentDropPiece.sy) {
            addCoins(5);
            addScore(1);
        }
    }
    resetPuzzleAndCheckWin();
}

function resetPuzzleAndCheckWin() {
    _stage.clearRect(0, 0, _puzzleWidth, _puzzleHeight);
    let gameWin = true;
    for (let i = 0; i < _pieces.length; i++) {
        let piece = _pieces[i];
        _stage.drawImage(_img, piece.sx, piece.sy, _pieceWidth, _pieceHeight, piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
        _stage.strokeRect(piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
        if (piece.xPos !== piece.sx || piece.yPos !== piece.sy) gameWin = false;
    }
    drawCoins();
    if (gameWin) {
        setTimeout(gameOver, 500);
    }
}

function gameOver() {
    document.onmousedown = null;
    document.getElementById('canvas').ontouchstart = null;
    document.onmousemove = null;
    document.getElementById('canvas').ontouchmove = null;
    document.onmouseup = null;
    document.getElementById('canvas').ontouchend = null;
    alert('🎉 Поздравляем! Пазл собран! 🎉');
    initPuzzle();   // начать заново с тем же изображением
}

function shuffleArray(o) {
    for (let j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

// ------------------- ЗАГРУЗКА ПОЛЬЗОВАТЕЛЬСКОЙ КАРТИНКИ -------------------
function loadUserImage(file) {
    const reader = new FileReader();
    reader.onload = function(ev) {
        const img = new Image();
        img.onload = function() {
            _img = img;
            onImage();  // пересоздаём пазл с новым изображением
            // Сбрасываем монетки и подсказки
            if (hintTimeout) clearTimeout(hintTimeout);
            hintActiveFor = null;
            coinsOnField = [];
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
}

// ------------------- ПОДСКАЗКА -------------------
function useHint() {
    if (_currentPiece === null) {
        alert("Сначала выберите фрагмент (нажмите на него)");
        return;
    }
    // Находим индекс текущего фрагмента
    const index = _pieces.findIndex(p => p === _currentPiece);
    if (index === -1) return;
    if (isPiecePlacedCorrectly(_currentPiece)) {
        alert("Этот фрагмент уже на своём месте!");
        return;
    }
    if (!spendCoins(5)) {
        alert("Не хватает монет (нужно 5💰)");
        return;
    }
    if (hintTimeout) clearTimeout(hintTimeout);
    hintActiveFor = index;
    // Автоматически снять подсветку через 2 секунды
    hintTimeout = setTimeout(() => {
        hintActiveFor = null;
        renderAll();
    }, 2000);
    renderAll();
}

// ------------------- САБОТАЖ (тряска + монеты) -------------------
function doSabotage() {
    if (!spendCoins(10)) {
        alert("Недостаточно монет для саботажа (нужно 10💰)");
        return;
    }
    // Тряска
    const canvasElem = document.getElementById('canvas');
    canvasElem.classList.add('shake');
    setTimeout(() => canvasElem.classList.remove('shake'), 500);
    
    // Генерируем от 5 до 100 монет
    const coinCount = Math.floor(Math.random() * 96) + 5;
    for (let i = 0; i < coinCount; i++) {
        let x = 20 + Math.random() * (_puzzleWidth - 40);
        let y = 20 + Math.random() * (_puzzleHeight - 40);
        let r = 12 + Math.random() * 8;
        coinsOnField.push({ x, y, r });
    }
    renderAll();
}

function drawCoins() {
    for (let coin of coinsOnField) {
        _stage.beginPath();
        _stage.arc(coin.x, coin.y, coin.r, 0, Math.PI*2);
        _stage.fillStyle = "#FFD966";
        _stage.shadowBlur = 4;
        _stage.fill();
        _stage.fillStyle = "#DAA520";
        _stage.font = `${coin.r+4}px "Segoe UI"`;
        _stage.fillText("💰", coin.x-8, coin.y+6);
        _stage.shadowBlur = 0;
    }
}

function handleCanvasClickForCoins(e) {
    if (!_canvas) return;
    const rect = _canvas.getBoundingClientRect();
    const scaleX = _canvas.width / rect.width;
    const scaleY = _canvas.height / rect.height;
    let clickX = (e.clientX - rect.left) * scaleX;
    let clickY = (e.clientY - rect.top) * scaleY;
    for (let i=0; i<coinsOnField.length; i++) {
        let coin = coinsOnField[i];
        let dx = clickX - coin.x;
        let dy = clickY - coin.y;
        if (Math.hypot(dx, dy) <= coin.r + 5) {
            addCoins(1);
            coinsOnField.splice(i,1);
            renderAll();
            return;
        }
    }
}

function renderAll() {
    if (!_stage) return;
    _stage.clearRect(0, 0, _puzzleWidth, _puzzleHeight);
    for (let piece of _pieces) {
        _stage.drawImage(_img, piece.sx, piece.sy, _pieceWidth, _pieceHeight, piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
        _stage.strokeRect(piece.xPos, piece.yPos, _pieceWidth, _pieceHeight);
    }
    drawCoins();
    if (hintActiveFor !== null && _pieces[hintActiveFor] && !isPiecePlacedCorrectly(_pieces[hintActiveFor])) {
        let target = _pieces[hintActiveFor];
        _stage.save();
        _stage.globalAlpha = 0.4;
        _stage.fillStyle = "#ff44aa";
        _stage.fillRect(target.sx, target.sy, _pieceWidth, _pieceHeight);
        _stage.restore();
        _stage.beginPath();
        _stage.strokeStyle = "#ff3399";
        _stage.lineWidth = 4;
        _stage.strokeRect(target.sx, target.sy, _pieceWidth, _pieceHeight);
    }
}

// ------------------- СМЕНА ИМЕНИ -------------------
function changePlayerName(newName) {
    if (!newName.trim()) newName = "Гость";
    const oldName = currentPlayerName;
    currentPlayerName = newName;
    // Обновляем рейтинг: переносим прогресс на новое имя
    let existing = ranking.find(p => p.name === currentPlayerName);
    if (existing && existing.name !== oldName) {
        // Если имя уже занято другим игроком, предлагаем объединить? По заданию – просто обновляем текущего.
        // Логичнее: удалить старую запись и добавить новую с текущими очками.
        const oldIdx = ranking.findIndex(p => p.name === oldName);
        if (oldIdx !== -1) ranking.splice(oldIdx,1);
        ranking.push({ name: currentPlayerName, score: totalPuzzlesCompleted, coins: playerCoins });
    } else {
        const idx = ranking.findIndex(p => p.name === oldName);
        if (idx !== -1) {
            ranking[idx].name = currentPlayerName;
            ranking[idx].score = totalPuzzlesCompleted;
            ranking[idx].coins = playerCoins;
        } else {
            ranking.push({ name: currentPlayerName, score: totalPuzzlesCompleted, coins: playerCoins });
        }
    }
    saveRanking();
    updateRankingUI();
}

// ------------------- ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ СТРАНИЦЫ -------------------
window.onload = function() {
    // Находим элементы управления
    const uploadInput = document.getElementById('imageUpload');
    const uploadBtn = document.getElementById('uploadBtn');
    const difficultySelect = document.getElementById('difficultySelect');
    const resetBtn = document.getElementById('resetBtn');
    const hintBtn = document.getElementById('hintBtn');
    const sabotageBtn = document.getElementById('sabotageBtn');
    const renameBtn = document.getElementById('renameBtn');
    const playerNameInput = document.getElementById('playerName');
    
    // Загружаем рейтинг и устанавливаем имя по умолчанию
    loadRanking();
    if (playerNameInput) playerNameInput.value = currentPlayerName;
    updateUI();
    
    // Обработчики
    if (uploadBtn) {
        uploadBtn.onclick = () => uploadInput.click();
    }
    if (uploadInput) {
        uploadInput.onchange = (e) => {
            if (e.target.files && e.target.files[0]) {
                loadUserImage(e.target.files[0]);
            }
        };
    }
    if (difficultySelect) {
        difficultySelect.onchange = (e) => {
            const newDiff = parseInt(e.target.value, 10);
            if (!isNaN(newDiff) && newDiff > 0) {
                PUZZLE_DIFFICULTY = newDiff;
                if (_img && _img.complete && _img.naturalWidth > 0) {
                    onImage();  // перезапуск с новой сложностью
                } else {
                    // Если картинки нет, загружаем дефолтную
                    _img = new Image();
                    _img.addEventListener('load', onImage, false);
                    _img.src = "img/puzzle.jpg";
                }
            }
        };
    }
    if (resetBtn) {
        resetBtn.onclick = () => {
            if (_img && _img.complete) {
                initPuzzle();
            }
        };
    }
    if (hintBtn) {
        hintBtn.onclick = useHint;
    }
    if (sabotageBtn) {
        sabotageBtn.onclick = doSabotage;
    }
    if (renameBtn && playerNameInput) {
        renameBtn.onclick = () => changePlayerName(playerNameInput.value);
    }
    
    // Перехватываем клики по canvas для монет
    _canvas = document.getElementById('canvas');
    if (_canvas) {
        _canvas.addEventListener('click', handleCanvasClickForCoins);
    }
    
    // Стартуем игру со стандартной картинкой и сложностью 10x10
    PUZZLE_DIFFICULTY = 10;
    _img = new Image();
    _img.addEventListener('load', onImage, false);
    _img.src = "img/puzzle.jpg";
};

// Добавим в CSS класс для тряски (если его нет в style.css)
const style = document.createElement('style');
style.textContent = `
    .shake {
        animation: shakeAnim 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
    }
    @keyframes shakeAnim {
        0% { transform: translate(0,0) rotate(0deg); }
        20% { transform: translate(-8px,2px) rotate(-1deg); }
        40% { transform: translate(8px,-3px) rotate(1deg); }
        60% { transform: translate(-4px,1px) rotate(0deg); }
        80% { transform: translate(4px,-1px) rotate(0deg); }
        100% { transform: translate(0,0) rotate(0); }
    }
    .rating-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 6px;
        border-bottom: 1px solid #ffbfd0;
        font-family: 'Segoe UI', sans-serif;
    }
`;
document.head.appendChild(style);

function escapeHtml(str) {
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}